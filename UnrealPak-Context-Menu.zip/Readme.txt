Place "UnrealPak-ContextMenu-With-Compression.bat" in any location (using an English-only path).
In the last line of "Add UnrealPak To Context Menu.reg", write the path to your 'UnrealPak-ContextMenu-With-Compression.bat' (remember to add an extra '' after each subfolder and the program name).
Example: “D:\Work\UnrealPak\UnrealPak-ContextMenu-With-Compression.bat\”
Refer to: “Adding UnrealPak Context Menu.gif”
Run "Add UnrealPak To Context Menu.reg" to create the context menu.
Right-click on a folder and select "UnrealPak Compress".